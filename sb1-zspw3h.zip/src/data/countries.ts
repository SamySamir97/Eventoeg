export const countries = [
  'Egypt',
  'Saudi Arabia',
  'United Arab Emirates',
  'Kuwait',
  'Qatar',
  'Bahrain',
  'Oman',
  'Jordan',
  'Lebanon',
  'Morocco',
  'Tunisia',
  'Algeria',
  'Sudan',
  'Libya',
  'Iraq',
  'Yemen'
];